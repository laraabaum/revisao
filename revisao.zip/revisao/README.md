1. Crie a pasta frontend e backend
2.  cd backend 
    npm i express cors mysql2 nodemon
3. Instalar Live Server e Thunder Client
4. npm init -y
5. Arrumar o package.json (colocar o start embaixo do test)
6. Criar a pasta src(dentro do backend) e criar o server.js dentro dela